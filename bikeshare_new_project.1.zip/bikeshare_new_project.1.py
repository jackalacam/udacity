import time
from typing import Optional
import pandas as pd
import numpy as np

CITY_DATA = {
    "chicago": "chicago.csv",
    "new york city": "new_york_city.csv",
    "washington": "washington.csv",
}


def get_specifics():
    """
    Ask the user to specify a city, month, or day to analyze.
    Returns:
        (str) city - name of the city
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name the day of week to filter by, or "all" to apply no day filter
    """
    print("Hello! Let's explore US bikeshare data!")

    # Define lists for valid inputs
    valid_cities = ["chicago", "new york city", "washington"]
    valid_months = ["all", "january", "february", "march", "april", "may", "june"]
    valid_days = [
        "all",
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
        "sunday",
    ]

    # get user input for city (chicago, new york city, washington).
    city = input("Enter the city (chicago, new york city, washington): ").lower()
    while city not in valid_cities:
        city = input(
            "Invalid input. Please choose either chicago, new york city or washington: "
        ).lower()

    # get user input for month (all, january, february, ... , june)
    month = input("Enter month (all, january, february, ... , june): ").lower()
    while month not in valid_months:
        month = input(
            "Invalid input. Please enter a valid month (all, january, february, ... , june): "
        ).lower()

    # get user input for day of week (all, monday, tuesday, ... sunday)
    day = input("Enter day (all, monday, tuesday, ... , sunday): ").lower()
    while day not in valid_days:
        day = input(
            "Invalid input. Please enter a valid day (all, monday, tuesday, ... , sunday): "
        ).lower()

    print("-" * 40)
    return city, month, day


def popular_time(df: pd.DataFrame, timeframe: str) -> None:
    if timeframe == "month":
        most_pop_time = df["start_time"].dt.month_name().mode()[0]
    elif timeframe == "day":
        most_pop_time = df["start_time"].dt.day_name().mode()[0]
    elif timeframe == "hour":
        most_pop_time = df["start_time"].dt.strftime("%I %p").mode()[0]
    print(f"The most popular {timeframe} is {most_pop_time}.")


def get_user_input(prompt: str, valid_responses: Optional[list[str]] = None) -> str:
    while True:
        response = input(prompt).lower()
        if valid_responses is None or response in valid_responses:
            return response
        print("Invalid input.")


def display_data(df):
    """Displays data if the user specifies that they would like to."""
    view_data = get_user_input(
        "\nWould you like to view more specific trip data? Type 'yes' or 'no'.\n",
        ["yes", "no"],
    )
    if view_data == "yes":
        i = 0
        while True:
            print(df.iloc[i : i + 5])
            i += 5
            more_data = get_user_input(
                "\nWould you like to view more specific trip data? Type 'yes' or 'no'.\n",
                ["yes", "no"],
            )
            if more_data == "no":
                break


def filter_by_time(df, time_period):
    if time_period in ["month", "day"]:
        filter_lower, filter_upper = get_time_period_bounds(time_period)
        df = df[(df["start_time"] >= filter_lower) & (df["start_time"] < filter_upper)]
    return df


def statistics():
    """Calculates and prints out the descriptive statistics about a city and
    time period specified by the user.
    Args:
        none.
    Returns:
        none.
    """
    # Filter by city (Chicago, New York, Washington)
    city = get_city()

    try:
        df = pd.read_csv(city, parse_dates=["Start Time", "End Time"])
    except FileNotFoundError:
        print(f"Could not find file {city}. Please check the file name and try again.")
        return

    # change all column names to lowercase letters and replace spaces with underscores
    df.columns = [col.replace(" ", "_").lower() for col in df.columns]

    # Filter by time period (month, day, none)
    time_period = get_time_period()

    print("Retrieving data.. please wait")
    df = filter_by_time(df, time_period)

    # creates a 'voyage' column that concatenates 'start_station' with
    # 'last_station' for the use popular_trip() function
    df["voyage"] = df["start_station"].str.cat(df["last_station"], sep=" to ")

    print("\nCalculating this statistic.. please wait")


def timed_statistics(function, *args):
    """Calls a function and prints how long it took.
     Args:
        function: the function to call
        *args: arguments to pass to the function
    Returns:
        The value returned by the function call
    """
    start_time = time.time()
    result = function(*args)
    print("That took %s seconds." % (time.time() - start_time))
    return result


def get_valid_response(prompt, valid_responses):
    """Continues to ask for input until a valid response is received.
    Args:
        prompt: The prompt to display to the user
        valid_responses: A list of responses to accept
    Returns:
        The valid input
    """
    while True:
        response = input(prompt).lower()
        if response in valid_responses:
            return response
        print("Invalid input.. try again")


if __name__ == "__main__":
    city_data_availability = {
        "chicago.csv": True,
        "new_york_city.csv": True,
        "washington.csv": False,
    }

    while True:
        # Filter by city (Chicago, New York, Washington)
        city = get_city()
        print("Loading data...")
        df = pd.read_csv(city, parse_dates=["Start Time", "End Time"])

        # Functions or the rest of the dataframe
        if  timed_function(popular_month, df) == "none":
            timed_function(popular_day, df)
            timed_function(popular_hour, df)
            timed_function(trip_duration, df)
            timed_function(popular_stations, df)
            timed_function(popular_trip, df)
            timed_function(users, df)

        if city_data_availability[city]:
            timed_function(gender, df)
            timed_function(birth_years, df)
            display_data(df)

        restart = get_valid_response("\nWould you like to restart? Type 'yes' or 'no'.\n", ["yes", "no"])
        if restart == "no":
            break